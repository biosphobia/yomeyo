(() => {
  // ../../packages/core/dist/deinflect.js
  var ANY = [];
  function r(from, to, toClass, reason, fromClass = ANY) {
    return { from, to, fromClass, toClass, reason };
  }
  var GODAN_TE = [
    ["\u3063\u3066", "\u3046", "v5u"],
    ["\u3063\u3066", "\u3064", "v5t"],
    ["\u3063\u3066", "\u308B", "v5r"],
    ["\u3044\u3066", "\u304F", "v5k"],
    ["\u3044\u3067", "\u3050", "v5g"],
    ["\u3057\u3066", "\u3059", "v5s"],
    ["\u3093\u3067", "\u306C", "v5n"],
    ["\u3093\u3067", "\u3076", "v5b"],
    ["\u3093\u3067", "\u3080", "v5m"]
  ];
  var GODAN_MASU = [
    ["\u3044", "\u3046", "v5u"],
    ["\u304D", "\u304F", "v5k"],
    ["\u304E", "\u3050", "v5g"],
    ["\u3057", "\u3059", "v5s"],
    ["\u3061", "\u3064", "v5t"],
    ["\u306B", "\u306C", "v5n"],
    ["\u3073", "\u3076", "v5b"],
    ["\u307F", "\u3080", "v5m"],
    ["\u308A", "\u308B", "v5r"]
  ];
  var GODAN_NAI = [
    ["\u308F", "\u3046", "v5u"],
    ["\u304B", "\u304F", "v5k"],
    ["\u304C", "\u3050", "v5g"],
    ["\u3055", "\u3059", "v5s"],
    ["\u305F", "\u3064", "v5t"],
    ["\u306A", "\u306C", "v5n"],
    ["\u3070", "\u3076", "v5b"],
    ["\u307E", "\u3080", "v5m"],
    ["\u3089", "\u308B", "v5r"]
  ];
  var GODAN_E = [
    ["\u3048", "\u3046", "v5u"],
    ["\u3051", "\u304F", "v5k"],
    ["\u3052", "\u3050", "v5g"],
    ["\u305B", "\u3059", "v5s"],
    ["\u3066", "\u3064", "v5t"],
    ["\u306D", "\u306C", "v5n"],
    ["\u3079", "\u3076", "v5b"],
    ["\u3081", "\u3080", "v5m"],
    ["\u308C", "\u308B", "v5r"]
  ];
  var GODAN_O = [
    ["\u304A\u3046", "\u3046", "v5u"],
    ["\u3053\u3046", "\u304F", "v5k"],
    ["\u3054\u3046", "\u3050", "v5g"],
    ["\u305D\u3046", "\u3059", "v5s"],
    ["\u3068\u3046", "\u3064", "v5t"],
    ["\u306E\u3046", "\u306C", "v5n"],
    ["\u307C\u3046", "\u3076", "v5b"],
    ["\u3082\u3046", "\u3080", "v5m"],
    ["\u308D\u3046", "\u308B", "v5r"]
  ];
  function buildRules() {
    const rules = [];
    const teAux = [
      ["\u3066\u3044\u308B", "\u3066", "progressive"],
      ["\u3067\u3044\u308B", "\u3067", "progressive"],
      ["\u3066\u308B", "\u3066", "progressive (casual)"],
      ["\u3067\u308B", "\u3067", "progressive (casual)"],
      ["\u3066\u3044\u305F", "\u3066", "past progressive"],
      ["\u3067\u3044\u305F", "\u3067", "past progressive"],
      ["\u3066\u305F", "\u3066", "past progressive (casual)"],
      ["\u3067\u305F", "\u3067", "past progressive (casual)"],
      ["\u3066\u3044\u306A\u3044", "\u3066", "negative progressive"],
      ["\u3067\u3044\u306A\u3044", "\u3067", "negative progressive"],
      ["\u3066\u306A\u3044", "\u3066", "negative progressive (casual)"],
      ["\u3067\u306A\u3044", "\u3067", "negative progressive (casual)"],
      ["\u3066\u3044\u307E\u3059", "\u3066", "polite progressive"],
      ["\u3067\u3044\u307E\u3059", "\u3067", "polite progressive"],
      ["\u3066\u3042\u308B", "\u3066", "-te aru"],
      ["\u3067\u3042\u308B", "\u3067", "-te aru"],
      ["\u3066\u304A\u304F", "\u3066", "-te oku"],
      ["\u3067\u304A\u304F", "\u3067", "-te oku"],
      ["\u3068\u304F", "\u3066", "-te oku (casual)"],
      ["\u3069\u304F", "\u3067", "-te oku (casual)"],
      ["\u3066\u3057\u307E\u3046", "\u3066", "-te shimau"],
      ["\u3067\u3057\u307E\u3046", "\u3067", "-te shimau"],
      ["\u3066\u3057\u307E\u3063\u305F", "\u3066", "-te shimau past"],
      ["\u3067\u3057\u307E\u3063\u305F", "\u3067", "-te shimau past"],
      ["\u3066\u3057\u307E\u3044\u307E\u3057\u305F", "\u3066", "-te shimau polite past"],
      ["\u3067\u3057\u307E\u3044\u307E\u3057\u305F", "\u3067", "-te shimau polite past"],
      ["\u3061\u3083\u3046", "\u3066", "-chau"],
      ["\u3058\u3083\u3046", "\u3067", "-chau"],
      ["\u3061\u3083\u3063\u305F", "\u3066", "-chatta"],
      ["\u3058\u3083\u3063\u305F", "\u3067", "-chatta"],
      ["\u3066\u304F\u3060\u3055\u3044", "\u3066", "-te kudasai"],
      ["\u3067\u304F\u3060\u3055\u3044", "\u3067", "-te kudasai"],
      ["\u3066\u304F\u308B", "\u3066", "-te kuru"],
      ["\u3067\u304F\u308B", "\u3067", "-te kuru"],
      ["\u3066\u3044\u304F", "\u3066", "-te iku"],
      ["\u3067\u3044\u304F", "\u3067", "-te iku"],
      ["\u3066\u307F\u308B", "\u3066", "-te miru"],
      ["\u3067\u307F\u308B", "\u3067", "-te miru"]
    ];
    for (const [from, to, reason] of teAux) {
      rules.push(r(from, to, ["te"], reason));
    }
    rules.push(r("\u3066", "\u308B", ["v1"], "-te", ["te"]));
    rules.push(r("\u3066", "\u308B", ["v1"], "-te"));
    for (const [from, to, cls] of GODAN_TE) {
      rules.push(r(from, to, [cls], "-te", ["te"]));
      rules.push(r(from, to, [cls], "-te"));
    }
    rules.push(r("\u3057\u3066", "\u3059\u308B", ["vs"], "-te"));
    rules.push(r("\u304D\u3066", "\u304F\u308B", ["vk"], "-te"));
    rules.push(r("\u6765\u3066", "\u6765\u308B", ["vk"], "-te"));
    rules.push(r("\u305F", "\u308B", ["v1"], "past", ["ta"]));
    rules.push(r("\u305F", "\u308B", ["v1"], "past"));
    for (const [teFrom, to, cls] of GODAN_TE) {
      const taFrom = teFrom.replace("\u3066", "\u305F").replace("\u3067", "\u3060");
      rules.push(r(taFrom, to, [cls], "past", ["ta"]));
      rules.push(r(taFrom, to, [cls], "past"));
    }
    rules.push(r("\u3057\u305F", "\u3059\u308B", ["vs"], "past"));
    rules.push(r("\u304D\u305F", "\u304F\u308B", ["vk"], "past"));
    rules.push(r("\u6765\u305F", "\u6765\u308B", ["vk"], "past"));
    rules.push(r("\u305F\u3089", "\u305F", ["ta"], "-tara"));
    rules.push(r("\u3060\u3089", "\u3060", ["ta"], "-tara"));
    rules.push(r("\u305F\u308A", "\u305F", ["ta"], "-tari"));
    rules.push(r("\u3060\u308A", "\u3060", ["ta"], "-tari"));
    const masuVariants = [
      ["\u307E\u3059", "polite"],
      ["\u307E\u3057\u305F", "polite past"],
      ["\u307E\u305B\u3093", "polite negative"],
      ["\u307E\u305B\u3093\u3067\u3057\u305F", "polite negative past"],
      ["\u307E\u3057\u3087\u3046", "polite volitional"]
    ];
    for (const [masu, reason] of masuVariants) {
      rules.push(r(masu, "\u308B", ["v1"], reason));
      for (const [stem, to, cls] of GODAN_MASU) {
        rules.push(r(stem + masu, to, [cls], reason));
      }
      rules.push(r("\u3057" + masu, "\u3059\u308B", ["vs"], reason));
      rules.push(r("\u304D" + masu, "\u304F\u308B", ["vk"], reason));
      rules.push(r("\u6765" + masu, "\u6765\u308B", ["vk"], reason));
    }
    rules.push(r("\u306A\u3044", "\u308B", ["v1"], "negative"));
    for (const [stem, to, cls] of GODAN_NAI) {
      rules.push(r(stem + "\u306A\u3044", to, [cls], "negative"));
    }
    rules.push(r("\u3057\u306A\u3044", "\u3059\u308B", ["vs"], "negative"));
    rules.push(r("\u3053\u306A\u3044", "\u304F\u308B", ["vk"], "negative"));
    rules.push(r("\u6765\u306A\u3044", "\u6765\u308B", ["vk"], "negative"));
    rules.push(r("\u306A\u304B\u3063\u305F", "\u306A\u3044", ["negform"], "negative past"));
    rules.push(r("\u306A\u304F\u3066", "\u306A\u3044", ["negform"], "negative -te"));
    rules.push(r("\u306A\u3051\u308C\u3070", "\u306A\u3044", ["negform"], "negative -ba"));
    rules.push(r("\u306A\u304D\u3083", "\u306A\u3044", ["negform"], "negative -kya"));
    rules.push(r("\u305F\u3044", "\u308B", ["v1"], "-tai"));
    for (const [stem, to, cls] of GODAN_MASU) {
      rules.push(r(stem + "\u305F\u3044", to, [cls], "-tai"));
    }
    rules.push(r("\u3057\u305F\u3044", "\u3059\u308B", ["vs"], "-tai"));
    rules.push(r("\u304D\u305F\u3044", "\u304F\u308B", ["vk"], "-tai"));
    rules.push(r("\u305F\u304B\u3063\u305F", "\u305F\u3044", ["taiform"], "-tai past"));
    rules.push(r("\u305F\u304F\u306A\u3044", "\u305F\u3044", ["taiform"], "-tai negative"));
    rules.push(r("\u305F\u304F\u3066", "\u305F\u3044", ["taiform"], "-tai -te"));
    rules.push(r("\u3089\u308C\u308B", "\u308B", ["v1"], "passive/potential"));
    rules.push(r("\u3089\u308C\u305F", "\u308B", ["v1"], "passive/potential past"));
    rules.push(r("\u3089\u308C\u306A\u3044", "\u308B", ["v1"], "passive/potential negative"));
    for (const [stem, to, cls] of GODAN_NAI) {
      rules.push(r(stem + "\u308C\u308B", to, [cls], "passive"));
      rules.push(r(stem + "\u308C\u305F", to, [cls], "passive past"));
      rules.push(r(stem + "\u308C\u306A\u3044", to, [cls], "passive negative"));
    }
    for (const [stem, to, cls] of GODAN_E) {
      rules.push(r(stem + "\u308B", to, [cls], "potential"));
      rules.push(r(stem + "\u305F", to, [cls], "potential past"));
      rules.push(r(stem + "\u306A\u3044", to, [cls], "potential negative"));
    }
    rules.push(r("\u3067\u304D\u308B", "\u3059\u308B", ["vs"], "potential"));
    rules.push(r("\u3055\u308C\u308B", "\u3059\u308B", ["vs"], "passive"));
    rules.push(r("\u3053\u3089\u308C\u308B", "\u304F\u308B", ["vk"], "passive/potential"));
    rules.push(r("\u3055\u305B\u308B", "\u308B", ["v1"], "causative"));
    for (const [stem, to, cls] of GODAN_NAI) {
      rules.push(r(stem + "\u305B\u308B", to, [cls], "causative"));
    }
    rules.push(r("\u3055\u305B\u308B", "\u3059\u308B", ["vs"], "causative"));
    rules.push(r("\u3053\u3055\u305B\u308B", "\u304F\u308B", ["vk"], "causative"));
    rules.push(r("\u308C\u3070", "\u308B", ["v1", "v5r"], "-ba"));
    for (const [stem, to, cls] of GODAN_E) {
      if (stem === "\u308C")
        continue;
      rules.push(r(stem + "\u3070", to, [cls], "-ba"));
    }
    rules.push(r("\u3059\u308C\u3070", "\u3059\u308B", ["vs"], "-ba"));
    rules.push(r("\u304F\u308C\u3070", "\u304F\u308B", ["vk"], "-ba"));
    rules.push(r("\u3051\u308C\u3070", "\u3044", ["adj-i"], "-ba (adj)"));
    rules.push(r("\u3088\u3046", "\u308B", ["v1"], "volitional"));
    for (const [from, to, cls] of GODAN_O) {
      rules.push(r(from, to, [cls], "volitional"));
    }
    rules.push(r("\u3057\u3088\u3046", "\u3059\u308B", ["vs"], "volitional"));
    rules.push(r("\u3053\u3088\u3046", "\u304F\u308B", ["vk"], "volitional"));
    rules.push(r("\u308D", "\u308B", ["v1"], "imperative"));
    rules.push(r("\u3057\u308D", "\u3059\u308B", ["vs"], "imperative"));
    rules.push(r("\u3053\u3044", "\u304F\u308B", ["vk"], "imperative"));
    for (const [stem, to, cls] of GODAN_E) {
      rules.push(r(stem, to, [cls], "imperative"));
    }
    rules.push(r("", "\u308B", ["v1"], "masu stem", ["masustem"]));
    rules.push(r("\u304B\u3063\u305F", "\u3044", ["adj-i"], "adj past"));
    rules.push(r("\u304F\u306A\u3044", "\u3044", ["adj-i"], "adj negative"));
    rules.push(r("\u304F\u306A\u304B\u3063\u305F", "\u3044", ["adj-i"], "adj negative past"));
    rules.push(r("\u304F\u3066", "\u3044", ["adj-i"], "adj -te"));
    rules.push(r("\u304F", "\u3044", ["adj-i"], "adverbial"));
    rules.push(r("\u3059\u304E\u308B", "\u3044", ["adj-i"], "-sugiru (adj)"));
    rules.push(r("\u305D\u3046", "\u3044", ["adj-i"], "-sou (adj)"));
    return rules;
  }
  var RULES = buildRules();
  function intermediateClasses(toClass) {
    return toClass;
  }
  var MAX_DEPTH = 6;
  function deinflect(text) {
    const results = [{ term: text, reasons: [], classes: [] }];
    const seen = /* @__PURE__ */ new Set([text + "\0"]);
    const queue = [{ term: text, reasons: [], classes: [], depth: 0 }];
    while (queue.length > 0) {
      const node = queue.shift();
      if (node.depth >= MAX_DEPTH)
        continue;
      for (const rule of RULES) {
        if (rule.from.length > 0 && !node.term.endsWith(rule.from))
          continue;
        if (rule.from.length === 0 && !(node.classes.length === 0 && node.term.length > 0)) {
          continue;
        }
        if (node.classes.length > 0) {
          if (rule.fromClass.length === 0) {
            const markers = ["te", "ta", "negform", "taiform", "adj-i", "v1"];
            if (!node.classes.some((c) => markers.includes(c)))
              continue;
          } else if (!rule.fromClass.some((c) => node.classes.includes(c))) {
            continue;
          }
        } else if (rule.fromClass.length > 0 && rule.from.length > 0) {
          continue;
        }
        const base = node.term.slice(0, node.term.length - rule.from.length);
        const produced = base + rule.to;
        if (produced.length === 0)
          continue;
        let classes = intermediateClasses(rule.toClass);
        if (rule.to === "\u3066" || rule.to === "\u3067")
          classes = ["te"];
        else if ((rule.to === "\u305F" || rule.to === "\u3060") && rule.reason.startsWith("-ta"))
          classes = ["ta"];
        else if (rule.to === "\u306A\u3044")
          classes = ["negform", "adj-i"];
        else if (rule.to === "\u305F\u3044")
          classes = ["taiform", "adj-i"];
        const reasons = [...node.reasons, rule.reason];
        const key = produced + "\0" + classes.join(",");
        if (seen.has(key))
          continue;
        seen.add(key);
        const isIntermediate = ["te", "ta", "negform", "taiform"].some((m) => classes.includes(m));
        if (!isIntermediate || rule.to === "\u306A\u3044" || rule.to === "\u305F\u3044") {
          results.push({ term: produced, reasons, classes });
        }
        queue.push({ term: produced, reasons, classes, depth: node.depth + 1 });
      }
    }
    return results;
  }
  function classesMatchPos(classes, pos) {
    if (classes.length === 0)
      return true;
    if (pos.length === 0)
      return true;
    for (const c of classes) {
      for (const p of pos) {
        if (p === c)
          return true;
        if (p.startsWith(c))
          return true;
        if (c === "v1" && (p === "v1-s" || p === "vz"))
          return true;
        if (c.startsWith("v5") && p === "v5")
          return true;
        if (c === "vs" && (p.startsWith("vs") || p === "vz"))
          return true;
        if (c === "adj-i" && p === "adj-ix")
          return true;
      }
    }
    return false;
  }

  // ../../packages/core/dist/dictionary.js
  var HIRAGANA_START = 12353;
  var KATAKANA_START = 12449;
  function kataToHira(text) {
    let out = "";
    for (const ch of text) {
      const code = ch.codePointAt(0);
      if (code >= 12449 && code <= 12534) {
        out += String.fromCodePoint(code - KATAKANA_START + HIRAGANA_START);
      } else {
        out += ch;
      }
    }
    return out;
  }
  function isJapaneseChar(ch) {
    const code = ch.codePointAt(0);
    if (code === void 0)
      return false;
    return code >= 12353 && code <= 12447 || // hiragana
    code >= 12448 && code <= 12543 || // katakana
    code >= 19968 && code <= 40959 || // CJK unified
    code >= 13312 && code <= 19903 || // CJK ext A
    code === 12293 || // 々
    code === 12540;
  }
  var MAX_SCAN_LENGTH = 32;
  var MAX_LOOKBEHIND = 18;
  function previousCharStart(text, index) {
    if (index <= 0)
      return -1;
    const back = index - 1;
    const code = text.charCodeAt(back);
    if (code >= 56320 && code <= 57343 && back > 0) {
      const high = text.charCodeAt(back - 1);
      if (high >= 55296 && high <= 56319)
        return back - 1;
    }
    return back;
  }
  function scanStarts(text, offset) {
    const starts = [offset];
    let at = offset;
    for (let i = 0; i < MAX_LOOKBEHIND; i++) {
      at = previousCharStart(text, at);
      if (at < 0)
        break;
      const point = text.codePointAt(at);
      if (point === void 0)
        break;
      if (!isJapaneseChar(String.fromCodePoint(point)))
        break;
      starts.push(at);
    }
    return starts;
  }
  function lookup(dict, text, offset = 0) {
    const matches = [];
    const seen = /* @__PURE__ */ new Set();
    for (const start of scanStarts(text, offset)) {
      const chars = [];
      for (const ch of text.slice(start)) {
        if (!isJapaneseChar(ch))
          break;
        chars.push(ch);
        if (chars.length >= MAX_SCAN_LENGTH)
          break;
      }
      if (chars.length === 0)
        continue;
      for (let len = chars.length; len >= 1; len--) {
        const fragment = chars.slice(0, len).join("");
        if (start + fragment.length <= offset)
          break;
        const candidates = [fragment];
        const hira = kataToHira(fragment);
        if (hira !== fragment)
          candidates.push(hira);
        for (const candidate of candidates) {
          for (const deinf of deinflect(candidate)) {
            const entries = dict.lookupExact(deinf.term).filter((e) => classesMatchPos(deinf.classes, e.pos));
            if (entries.length === 0)
              continue;
            const key = start + " " + fragment + " " + deinf.term;
            if (seen.has(key))
              continue;
            seen.add(key);
            matches.push({
              matchedText: fragment,
              start,
              matchLength: len,
              term: deinf.term,
              reasons: deinf.reasons,
              entries: rankEntries(entries)
            });
          }
        }
      }
    }
    matches.sort((a, b) => {
      if (a.matchLength !== b.matchLength)
        return b.matchLength - a.matchLength;
      if (a.reasons.length !== b.reasons.length)
        return a.reasons.length - b.reasons.length;
      const kanjiA = startsWithKanji(a.matchedText);
      const kanjiB = startsWithKanji(b.matchedText);
      if (kanjiA !== kanjiB)
        return kanjiA ? -1 : 1;
      const freqA = a.entries[0]?.freq ?? 1e9;
      const freqB = b.entries[0]?.freq ?? 1e9;
      if (freqA !== freqB)
        return freqA - freqB;
      return a.start - b.start;
    });
    return matches;
  }
  function rankEntries(entries) {
    const order = /* @__PURE__ */ new Map();
    for (const entry of entries) {
      const key = entry.source ?? "";
      if (!order.has(key))
        order.set(key, order.size);
    }
    return entries.map((entry, index) => ({ entry, index })).sort((a, b) => {
      const sourceA = order.get(a.entry.source ?? "") ?? 0;
      const sourceB = order.get(b.entry.source ?? "") ?? 0;
      if (sourceA !== sourceB)
        return sourceA - sourceB;
      const freqA = a.entry.freq ?? 1e9;
      const freqB = b.entry.freq ?? 1e9;
      if (freqA !== freqB)
        return freqA - freqB;
      return a.index - b.index;
    }).map((x) => x.entry);
  }
  function startsWithKanji(text) {
    const code = text.codePointAt(0);
    return code !== void 0 && (code >= 19968 && code <= 40959 || code >= 13312 && code <= 19903);
  }

  // ../../packages/core/dist/srs.js
  var DEFAULT_SRS_CONFIG = {
    learningStepsMin: [1, 10],
    relearningStepsMin: [10],
    graduatingIntervalDays: 1,
    easyIntervalDays: 4,
    startingEase: 2.5,
    minEase: 1.3,
    easyBonus: 1.3,
    hardMultiplier: 1.2,
    lapseMultiplier: 0.5,
    maxIntervalDays: 365 * 10
  };
  var MIN_MS = 60 * 1e3;
  var DAY_MS = 24 * 60 * 60 * 1e3;
  function newCardSchedule(now, config = DEFAULT_SRS_CONFIG) {
    return {
      state: "new",
      due: now,
      intervalDays: 0,
      ease: config.startingEase,
      stepIndex: 0,
      reps: 0,
      lapses: 0
    };
  }

  // ../../packages/core/dist/sync.js
  function mergeCards(local, incoming) {
    const applied = [];
    for (const card of incoming) {
      const existing = local.get(card.id);
      if (!existing || card.updatedAt > existing.updatedAt) {
        local.set(card.id, card);
        applied.push(card);
      }
    }
    return applied;
  }

  // ../../packages/core/dist/card.js
  function makeId() {
    const cryptoObj = globalThis.crypto;
    if (cryptoObj && "randomUUID" in cryptoObj)
      return cryptoObj.randomUUID();
    let s = "";
    for (let i = 0; i < 32; i++)
      s += Math.floor(Math.random() * 16).toString(16);
    return s;
  }
  function cardKey(term, reading) {
    return `${term.trim()}\0${(reading || term).trim()}`;
  }
  function findDuplicate(cards, term, reading) {
    const key = cardKey(term, reading);
    for (const card of cards) {
      if (!card.deleted && cardKey(card.term, card.reading) === key)
        return card;
    }
    return void 0;
  }
  function createCard(input, now) {
    return {
      id: makeId(),
      term: input.term,
      reading: input.reading,
      glosses: input.glosses,
      sentence: input.sentence,
      source: input.source,
      createdAt: now,
      updatedAt: now,
      ...newCardSchedule(now)
    };
  }

  // ../../packages/core/dist/dict-binary.js
  var MAGIC = 844713305;
  var HEADER_BYTES = 64;
  function isBinaryDict(buffer) {
    if (buffer.byteLength < HEADER_BYTES)
      return false;
    return new DataView(buffer).getUint32(0, true) === MAGIC;
  }
  function compareBytes(a, aStart, aEnd, b, bStart, bEnd) {
    const aLen = aEnd - aStart;
    const bLen = bEnd - bStart;
    const shared = aLen < bLen ? aLen : bLen;
    for (let i = 0; i < shared; i++) {
      const diff = a[aStart + i] - b[bStart + i];
      if (diff !== 0)
        return diff;
    }
    return aLen - bLen;
  }
  var BinaryDictionary = class {
    bytes;
    keyOffsets;
    postOffsets;
    postings;
    entOffsets;
    offKeyBlob;
    offEntryBlob;
    keyCount;
    encoder = new TextEncoder();
    decoder = new TextDecoder();
    /** Decoded entries, kept so repeated taps on a word do no work twice. */
    cache = /* @__PURE__ */ new Map();
    size;
    pos;
    meta;
    /** Tags every entry with where it came from, for the multi-dictionary UI. */
    source;
    constructor(buffer, source) {
      if (!isBinaryDict(buffer))
        throw new Error("Not a Yomeyo binary dictionary");
      const view = new DataView(buffer);
      if (view.getUint32(4, true) !== 2) {
        throw new Error("This dictionary was built by a newer version of Yomeyo");
      }
      this.bytes = new Uint8Array(buffer);
      this.keyCount = view.getUint32(8, true);
      this.size = view.getUint32(12, true);
      this.keyOffsets = new Uint32Array(buffer, view.getUint32(16, true), this.keyCount + 1);
      this.offKeyBlob = view.getUint32(20, true);
      this.postOffsets = new Uint32Array(buffer, view.getUint32(24, true), this.keyCount + 1);
      const offPostings = view.getUint32(28, true);
      const offEntOffsets = view.getUint32(32, true);
      this.postings = new Uint32Array(buffer, offPostings, (offEntOffsets - offPostings) / 4);
      this.entOffsets = new Uint32Array(buffer, offEntOffsets, this.size + 1);
      this.offEntryBlob = view.getUint32(36, true);
      const tail = JSON.parse(this.decoder.decode(this.bytes.subarray(view.getUint32(40, true), view.getUint32(40, true) + view.getUint32(44, true))));
      this.pos = tail.pos ?? [];
      this.meta = tail.meta;
      this.source = source;
    }
    /** Index of `needle` among the sorted keys, or -1. */
    find(needle) {
      let lo = 0;
      let hi = this.keyCount - 1;
      while (lo <= hi) {
        const mid = lo + hi >> 1;
        const start = this.offKeyBlob + this.keyOffsets[mid];
        const end = this.offKeyBlob + this.keyOffsets[mid + 1];
        const cmp = compareBytes(this.bytes, start, end, needle, 0, needle.length);
        if (cmp === 0)
          return mid;
        if (cmp < 0)
          lo = mid + 1;
        else
          hi = mid - 1;
      }
      return -1;
    }
    decodeAt(id) {
      const json = this.decoder.decode(this.bytes.subarray(this.offEntryBlob + this.entOffsets[id], this.offEntryBlob + this.entOffsets[id + 1]));
      const [term, reading, posIdx, glosses, freq] = JSON.parse(json);
      const entry = {
        term,
        reading,
        pos: posIdx.map((i) => this.pos[i]).filter((p) => p !== void 0),
        glosses
      };
      if (freq !== void 0)
        entry.freq = freq;
      if (this.source)
        entry.source = this.source;
      return entry;
    }
    entryAt(id) {
      const cached = this.cache.get(id);
      if (cached)
        return cached;
      const entry = this.decodeAt(id);
      this.cache.set(id, entry);
      return entry;
    }
    /**
     * Every entry once, decoded on the fly and deliberately not cached — for
     * one-off scans (finding words made of certain kana, say) that must not
     * leave the whole dictionary sitting decoded in memory afterwards.
     */
    *entries() {
      for (let id = 0; id < this.size; id++)
        yield this.decodeAt(id);
    }
    /**
     * Words whose reading uses only the given characters — what the kana game
     * asks for when it needs real words spelt with the rows you have picked.
     *
     * Walking `entries()` for this decodes every entry in the dictionary, which
     * is a JSON parse each and long enough on a phone to look like a hang. This
     * walks the sorted key index instead. Two arithmetic tests throw out almost
     * every key before anything is decoded: a kana is always three UTF-8 bytes,
     * so a key of two to four kana is a key of six to twelve bytes, and every
     * one of them begins 0xE3. Only what survives is decoded, and only what
     * matches is looked up in full.
     */
    wordsMadeOf(allowed, minLength = 2, maxLength = 4) {
      const out = [];
      for (let k = 0; k < this.keyCount; k++) {
        const start = this.offKeyBlob + this.keyOffsets[k];
        const end = this.offKeyBlob + this.keyOffsets[k + 1];
        const length = end - start;
        if (length < minLength * 3 || length > maxLength * 3 || length % 3 !== 0)
          continue;
        if (this.bytes[start] !== 227)
          continue;
        const key = this.decoder.decode(this.bytes.subarray(start, end));
        let ok = true;
        for (const ch of key) {
          if (!allowed.has(ch)) {
            ok = false;
            break;
          }
        }
        if (!ok)
          continue;
        for (let i = this.postOffsets[k]; i < this.postOffsets[k + 1]; i++) {
          const entry = this.decodeAt(this.postings[i]);
          if (entry.reading === key)
            out.push(entry);
        }
      }
      return out;
    }
    lookupExact(text) {
      const at = this.find(this.encoder.encode(text));
      if (at < 0)
        return [];
      const from = this.postOffsets[at];
      const to = this.postOffsets[at + 1];
      const out = new Array(to - from);
      for (let i = from; i < to; i++)
        out[i - from] = this.entryAt(this.postings[i]);
      return out;
    }
  };

  // src/browser.ts
  var globalAny = globalThis;
  var ext = typeof globalAny.browser !== "undefined" && globalAny.browser?.runtime ? globalAny.browser : globalAny.chrome;
  var promiseStyle = typeof globalAny.browser !== "undefined" && globalAny.browser?.runtime !== void 0;
  function storageGet(keys) {
    if (promiseStyle) return ext.storage.local.get(keys);
    return new Promise((resolve) => ext.storage.local.get(keys, resolve));
  }
  function storageSet(items) {
    if (promiseStyle) return ext.storage.local.set(items);
    return new Promise((resolve) => ext.storage.local.set(items, () => resolve()));
  }
  function resourceUrl(path) {
    return ext.runtime.getURL(path);
  }
  async function tabsMatching(urlPattern) {
    const query = { url: urlPattern };
    try {
      const tabs = promiseStyle ? await ext.tabs.query(query) : await new Promise((resolve) => ext.tabs.query(query, resolve));
      return tabs ?? [];
    } catch {
      return [];
    }
  }
  async function activeTab() {
    const query = { active: true, currentWindow: true };
    try {
      const tabs = promiseStyle ? await ext.tabs.query(query) : await new Promise((resolve) => ext.tabs.query(query, resolve));
      return tabs?.[0] ?? null;
    } catch {
      return null;
    }
  }
  async function sendToTab(tabId, message) {
    try {
      if (promiseStyle) return await ext.tabs.sendMessage(tabId, message);
      return await new Promise((resolve) => {
        ext.tabs.sendMessage(tabId, message, (response) => {
          void ext.runtime.lastError;
          resolve(response ?? null);
        });
      });
    } catch {
      return null;
    }
  }

  // src/frame-handoff.ts
  function syncFrameUrl(appUrl) {
    const base = appUrl.endsWith("/") ? appUrl : appUrl + "/";
    return new URL("sync.html", base).href;
  }

  // src/background.ts
  var DEFAULT_APP_URL = "https://duugu.moe/yomeyo/";
  var OLD_APP_URLS = ["https://biosphobia.github.io/yomeyo/", "https://biosphobia.github.io/yomeyo"];
  async function migrateAppUrl() {
    const data = await storageGet("settings");
    const settings = data.settings;
    if (!settings) return;
    const current = settings.appUrl?.trim() ?? "";
    if (current !== "" && !OLD_APP_URLS.includes(current.replace(/\/index\.html$/, ""))) return;
    await storageSet({ settings: { ...settings, appUrl: DEFAULT_APP_URL } });
  }
  var dictPromise = null;
  function getDictionary() {
    if (!dictPromise) {
      dictPromise = fetch(resourceUrl("dict/dict.bin")).then((res) => res.arrayBuffer()).then((buffer) => new BinaryDictionary(buffer)).catch((err) => {
        dictPromise = null;
        throw err;
      });
    }
    return dictPromise;
  }
  async function getCards() {
    const data = await storageGet("cards");
    return data.cards ?? {};
  }
  async function setCards(cards) {
    await storageSet({ cards });
  }
  async function handleSave(entry, sentence, url, fromTab) {
    const cards = await getCards();
    if (findDuplicate(Object.values(cards), entry.term, entry.reading)) return "duplicate";
    const card = {
      ...createCard(
        {
          term: entry.term,
          reading: entry.reading,
          glosses: entry.glosses,
          sentence,
          source: url
        },
        Date.now()
      ),
      dirty: true
    };
    cards[card.id] = card;
    await setCards(cards);
    void tellAppAboutNewWords();
    deliverSoon(fromTab);
    return "saved";
  }
  async function pendingForApp() {
    const cards = await getCards();
    return Object.values(cards).filter((c) => !c.deleted && !c.handedOff).sort((a, b) => a.createdAt - b.createdAt).slice(0, 500).map(({ dirty: _dirty, handedOff: _handedOff, ...card }) => card);
  }
  async function appUrlSetting() {
    const settings = await storageGet("settings");
    return settings.settings?.appUrl?.trim() || DEFAULT_APP_URL;
  }
  function originOf(url) {
    try {
      return new URL(url).origin;
    } catch {
      return null;
    }
  }
  async function tokenFor(appUrl) {
    const origin = originOf(appUrl);
    if (!origin) return void 0;
    const data = await storageGet([
      "handoverTokens",
      "handoverToken"
    ]);
    return data.handoverTokens?.[origin] ?? data.handoverToken;
  }
  async function rememberToken(appUrl, token) {
    const origin = originOf(appUrl);
    if (!origin) return;
    const data = await storageGet("handoverTokens");
    await storageSet({ handoverTokens: { ...data.handoverTokens ?? {}, [origin]: token } });
  }
  async function noteDelivery(state, delivered, detail) {
    const note = { at: Date.now(), state, delivered };
    if (detail) note.detail = detail;
    await storageSet({ lastDelivery: note });
  }
  async function tellAppAboutNewWords() {
    const appUrl = await appUrlSetting();
    const pattern = appUrl.replace(/[^/]*$/, "") + "*";
    for (const tab of await tabsMatching(pattern)) {
      if (tab.id !== void 0) void sendToTab(tab.id, { type: "appHasNewWords" });
    }
  }
  var delivering = Promise.resolve();
  async function deliveryTabs(preferred) {
    const ids = [];
    if (preferred !== void 0) ids.push(preferred);
    const active = await activeTab();
    if (active?.id !== void 0 && !ids.includes(active.id)) ids.push(active.id);
    for (const pattern of ["https://*/*", "http://*/*"]) {
      for (const tab of await tabsMatching(pattern).catch(() => [])) {
        if (tab.id !== void 0 && !ids.includes(tab.id)) ids.push(tab.id);
      }
    }
    return ids.slice(0, 8);
  }
  async function deliverToApp(preferredTab) {
    const pending = await pendingForApp();
    if (pending.length === 0) {
      await noteDelivery("nothing-to-do", 0);
      return "nothing-to-do";
    }
    const appUrl = await appUrlSetting();
    const token = await tokenFor(appUrl);
    if (!token) {
      await noteDelivery("not-linked", 0);
      return "not-linked";
    }
    const frameUrl = syncFrameUrl(appUrl);
    let refused = false;
    let detail = "";
    const tabs = await deliveryTabs(preferredTab);
    for (const tabId of tabs) {
      const res = await sendToTab(tabId, {
        type: "deliverViaFrame",
        frameUrl,
        cards: pending,
        token
      });
      if (res?.ids) {
        await markHandedOff(res.ids);
        await noteDelivery("delivered", res.ids.length);
        return "delivered";
      }
      if (res?.error) {
        detail = res.error;
        if (/not linked|refused/i.test(res.error)) refused = true;
      }
      if (refused) break;
    }
    const state = refused ? "refused" : tabs.length === 0 ? "no-page" : "failed";
    await noteDelivery(state, 0, detail);
    return state;
  }
  function deliverSoon(preferredTab) {
    delivering = delivering.catch(() => {
    }).then(async () => {
      await deliverToApp(preferredTab).catch(() => {
      });
    });
  }
  async function fetchForApp(url) {
    if (typeof url !== "string" || !/^https?:\/\//i.test(url)) return { error: "not a http(s) url" };
    const origin = (() => {
      try {
        return new URL(url).origin + "/*";
      } catch {
        return null;
      }
    })();
    if (!origin) return { error: "not a valid url" };
    try {
      const allowed = await new Promise((resolve) => {
        try {
          const result = ext.permissions?.contains({ origins: [origin] }, resolve);
          if (result && typeof result.then === "function") result.then(resolve, () => resolve(false));
        } catch {
          resolve(false);
        }
      });
      if (!allowed) return { error: "not allowed to fetch that yet" };
    } catch {
      return { error: "could not check permissions" };
    }
    try {
      const res = await fetch(url);
      if (!res.ok) return { error: `the service returned ${res.status}` };
      const buffer = await res.arrayBuffer();
      const bytes = new Uint8Array(buffer);
      let binary = "";
      for (let i = 0; i < bytes.length; i += 32768) {
        binary += String.fromCharCode(...bytes.subarray(i, i + 32768));
      }
      return { base64: btoa(binary), contentType: res.headers.get("content-type") ?? "application/octet-stream" };
    } catch (err) {
      return { error: err instanceof Error ? err.message : String(err) };
    }
  }
  async function markHandedOff(ids) {
    if (!Array.isArray(ids) || ids.length === 0) return 0;
    const cards = await getCards();
    let marked = 0;
    for (const id of ids) {
      const card = typeof id === "string" ? cards[id] : void 0;
      if (card && !card.handedOff) {
        cards[id] = { ...card, handedOff: true };
        marked++;
      }
    }
    if (marked > 0) {
      await setCards(cards);
      await storageSet({ lastHandoffAt: Date.now() });
    }
    return marked;
  }
  async function isSaved(term, reading) {
    const cards = await getCards();
    return Object.values(cards).some((c) => !c.deleted && c.term === term && c.reading === reading);
  }
  async function handleSync() {
    const data = await storageGet(["settings", "syncSince"]);
    const settings = data.settings ?? {};
    if (!settings.url || !settings.token) {
      throw new Error("Set the sync server URL and token first.");
    }
    const since = data.syncSince ?? 0;
    const cards = await getCards();
    const dirty = Object.values(cards).filter((c) => c.dirty);
    const request = {
      since,
      changes: dirty.map(({ dirty: _dirty, ...card }) => card)
    };
    const res = await fetch(settings.url.replace(/\/+$/, "") + "/sync", {
      method: "POST",
      headers: {
        "content-type": "application/json",
        authorization: `Bearer ${settings.token}`
      },
      body: JSON.stringify(request)
    });
    if (!res.ok) {
      throw new Error(res.status === 401 ? "Wrong sync token." : `Sync failed (${res.status}).`);
    }
    const response = await res.json();
    const map = new Map(Object.entries(cards));
    const applied = mergeCards(map, response.changes);
    const appliedIds = new Set(applied.map((c) => c.id));
    const pushedIds = new Set(dirty.map((c) => c.id));
    const next = {};
    for (const [id, card] of map) {
      const wasPushed = pushedIds.has(id);
      const wasPulled = appliedIds.has(id);
      const stillDirty = (cards[id]?.dirty ?? false) && !wasPushed && !wasPulled;
      next[id] = { ...card, dirty: stillDirty };
    }
    await setCards(next);
    await storageSet({ syncSince: response.now });
    return { pushed: dirty.length, pulled: applied.length };
  }
  ext.runtime.onMessage.addListener((message, sender, sendResponse) => {
    (async () => {
      switch (message?.type) {
        // A page has finished loading. Start the dictionary now, while the
        // user is still reading, rather than on the tap they are waiting for.
        // Used by the toolbar popup, and after a browser restart, to flush
        // anything that could not be delivered at the time it was saved.
        case "deliverNow": {
          try {
            sendResponse({ ok: true, state: await deliverToApp() });
          } catch (err) {
            sendResponse({ error: err instanceof Error ? err.message : String(err) });
          }
          break;
        }
        /*
         * The button in the toolbar menu.
         *
         * It used to be a sync-server push, which almost nobody has one of, so
         * pressing it said "set the sync server URL and token first" — an
         * error about a thing that is not how words travel. The words travel
         * by the hidden frame; that is what this does, and the server is only
         * touched when somebody has actually configured one.
         */
        case "pushNow": {
          try {
            const state = await deliverToApp();
            const data = await storageGet("settings");
            const server = data.settings;
            let synced;
            if (server?.url && server.token) synced = await handleSync().catch(() => void 0);
            sendResponse({ state, appUrl: await appUrlSetting(), synced });
          } catch (err) {
            sendResponse({ error: err instanceof Error ? err.message : String(err) });
          }
          break;
        }
        case "warm": {
          void getDictionary().catch(() => {
          });
          sendResponse({ ok: true });
          break;
        }
        case "pendingForApp": {
          sendResponse(await pendingForApp());
          break;
        }
        case "fetchForApp": {
          sendResponse(await fetchForApp(message.url));
          break;
        }
        case "setHandoverToken": {
          if (typeof message.token === "string" && message.token.length >= 32) {
            await rememberToken(typeof sender?.tab?.url === "string" ? sender.tab.url : await appUrlSetting(), message.token);
            await storageSet({ handoverToken: message.token });
            deliverSoon(sender?.tab?.id);
          }
          sendResponse({ ok: true });
          break;
        }
        case "handedOff": {
          sendResponse({ marked: await markHandedOff(message.ids) });
          break;
        }
        case "lookup": {
          const dict = await getDictionary();
          const matches = lookup(dict, message.text, message.offset ?? 0);
          sendResponse(matches.slice(0, 8));
          break;
        }
        case "save": {
          const outcome = await handleSave(message.entry, message.sentence, message.url, sender?.tab?.id);
          sendResponse({ ok: true, outcome });
          break;
        }
        case "isSaved": {
          sendResponse(await isSaved(message.term, message.reading));
          break;
        }
        case "stats": {
          const cards = await getCards();
          const live = Object.values(cards).filter((c) => !c.deleted);
          const meta = await storageGet([
            "lastHandoffAt",
            "lastDelivery"
          ]);
          const appUrl = await appUrlSetting();
          sendResponse({
            total: live.length,
            waiting: live.filter((c) => !c.handedOff).length,
            dirty: live.filter((c) => c.dirty).length,
            lastHandoffAt: meta.lastHandoffAt ?? null,
            version: ext.runtime.getManifest?.().version ?? null,
            appUrl,
            // Whether this app has ever handed over the secret that lets words
            // in. Without it nothing can arrive, however many times it tries.
            linked: await tokenFor(appUrl) !== void 0,
            lastDelivery: meta.lastDelivery ?? null
          });
          break;
        }
        case "sync": {
          try {
            sendResponse(await handleSync());
          } catch (err) {
            sendResponse({ error: err instanceof Error ? err.message : String(err) });
          }
          break;
        }
        case "getSettings": {
          const data = await storageGet(["settings", "tapMode", "showToggle"]);
          sendResponse({
            settings: { appUrl: DEFAULT_APP_URL, ...data.settings ?? {} },
            tapMode: data.tapMode ?? null,
            showToggle: data.showToggle !== false
          });
          break;
        }
        case "setSettings": {
          await storageSet({ settings: message.settings });
          sendResponse({ ok: true });
          break;
        }
        case "setTapMode": {
          await storageSet({ tapMode: message.enabled });
          sendResponse({ ok: true });
          break;
        }
        case "setShowToggle": {
          await storageSet({ showToggle: message.enabled });
          sendResponse({ ok: true });
          break;
        }
        default:
          sendResponse(null);
      }
    })();
    return true;
  });
  ext.runtime.onStartup?.addListener(() => void migrateAppUrl().then(() => deliverSoon()));
  ext.runtime.onInstalled?.addListener(() => void migrateAppUrl().then(() => deliverSoon()));
  var FLUSH_ALARM = "yomeyo-flush";
  ext.alarms?.create?.(FLUSH_ALARM, { periodInMinutes: 5, delayInMinutes: 1 });
  ext.alarms?.onAlarm?.addListener((alarm) => {
    if (alarm?.name !== FLUSH_ALARM) return;
    void (async () => {
      if ((await pendingForApp()).length === 0) return;
      deliverSoon();
    })();
  });
  var lastAutoFlush = 0;
  ext.tabs?.onUpdated?.addListener((tabId, info, tab) => {
    if (info?.status !== "complete") return;
    if (typeof tab?.url !== "string" || !/^https?:/i.test(tab.url)) return;
    const now = Date.now();
    if (now - lastAutoFlush < 1e4) return;
    lastAutoFlush = now;
    void (async () => {
      if ((await pendingForApp()).length === 0) return;
      deliverSoon(tabId);
    })();
  });
})();
