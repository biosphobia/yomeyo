(() => {
  // src/browser.ts
  var globalAny = globalThis;
  var ext = typeof globalAny.browser !== "undefined" && globalAny.browser?.runtime ? globalAny.browser : globalAny.chrome;
  var promiseStyle = typeof globalAny.browser !== "undefined" && globalAny.browser?.runtime !== void 0;
  function sendMessage(message) {
    if (promiseStyle) return ext.runtime.sendMessage(message);
    return new Promise((resolve) => {
      ext.runtime.sendMessage(message, (response) => {
        void ext.runtime.lastError;
        resolve(response);
      });
    });
  }
  function storageGet(keys) {
    if (promiseStyle) return ext.storage.local.get(keys);
    return new Promise((resolve) => ext.storage.local.get(keys, resolve));
  }
  async function activeTab() {
    const query = { active: true, currentWindow: true };
    try {
      const tabs = promiseStyle ? await ext.tabs.query(query) : await new Promise((resolve) => ext.tabs.query(query, resolve));
      return tabs?.[0] ?? null;
    } catch {
      return null;
    }
  }
  async function sendToTab(tabId, message) {
    try {
      if (promiseStyle) return await ext.tabs.sendMessage(tabId, message);
      return await new Promise((resolve) => {
        ext.tabs.sendMessage(tabId, message, (response) => {
          void ext.runtime.lastError;
          resolve(response ?? null);
        });
      });
    } catch {
      return null;
    }
  }

  // src/popup.ts
  var IS_TOUCH = typeof matchMedia === "function" ? matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0 : navigator.maxTouchPoints > 0;
  var $ = (id) => document.getElementById(id);
  var tapToggle = $("tap-mode");
  var showToggleInput = $("show-toggle");
  var tapHint = $("tap-hint");
  var appUrlInput = $("app-url");
  var urlInput = $("sync-url");
  var tokenInput = $("sync-token");
  var pushBtn = $("push-btn");
  var openAppBtn = $("open-app");
  var msg = $("msg");
  var statTotal = $("stat-total");
  var statWaiting = $("stat-waiting");
  var transferHint = $("transfer-hint");
  var audioHint = $("audio-hint");
  var audioAllowBtn = $("audio-allow");
  var versionLabel = $("version-label");
  var appUrl = "";
  function describeWhen(at) {
    const seconds = Math.max(0, Math.round((Date.now() - at) / 1e3));
    if (seconds < 60) return "just now";
    const minutes = Math.round(seconds / 60);
    if (minutes < 60) return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
    const hours = Math.round(minutes / 60);
    if (hours < 24) return `${hours} hour${hours === 1 ? "" : "s"} ago`;
    const days = Math.round(hours / 24);
    return `${days} day${days === 1 ? "" : "s"} ago`;
  }
  function explain(state, where) {
    const host = (() => {
      try {
        return new URL(where).host;
      } catch {
        return where;
      }
    })();
    switch (state) {
      case "not-linked":
        return `Open ${host} once in this browser. The app hands the extension a key on its own page, and nothing can be added without it.`;
      case "refused":
        return `${host} would not take them: it does not recognise this extension. Open it once and they will go across.`;
      case "no-page":
        return "No ordinary web page is open to send them through. Open any site and they go on their own.";
      case "failed":
        return "The last attempt could not get through. It tries again by itself, on every page you open.";
      default:
        return "";
    }
  }
  function describeTransfer(stats) {
    if (stats.total === 0) return "Tap a Japanese word on any page to save it.";
    if (stats.waiting === 0) {
      return `Everything saved here is in the app${stats.lastHandoffAt ? ` (last added ${describeWhen(stats.lastHandoffAt)})` : ""}.`;
    }
    const why = explain(stats.lastDelivery?.state, stats.appUrl ?? "");
    return why || "Some words have not reached the app yet. They keep trying on their own.";
  }
  function setMessage(text, kind = "") {
    msg.textContent = text;
    msg.className = kind ? `msg ${kind}` : "msg";
  }
  function updateHint() {
    tapHint.textContent = tapToggle.checked ? "Tap any Japanese word on a page to look it up." : IS_TOUCH ? "Off." : "Off. Hold Alt/Option and click a word instead.";
  }
  async function effectiveTapMode(stored) {
    try {
      const tab = await activeTab();
      if (tab?.id !== void 0) {
        const state = await sendToTab(tab.id, { type: "getTapState" });
        if (typeof state?.active === "boolean") return state.active;
      }
    } catch {
    }
    return typeof stored === "boolean" ? stored : IS_TOUCH;
  }
  async function refresh() {
    const stored = await storageGet([
      "tapMode",
      "showToggle"
    ]).catch(() => ({}));
    tapToggle.checked = await effectiveTapMode(
      typeof stored.tapMode === "boolean" ? stored.tapMode : null
    );
    showToggleInput.checked = stored.showToggle !== false;
    updateHint();
    const reply = await sendMessage({ type: "getSettings" }).catch(() => void 0);
    if (!reply) {
      setMessage(
        "Yomeyo's background is not responding, so lookups will not work. Close and reopen this menu; if it keeps happening, remove the extension and install it again.",
        "error"
      );
      statTotal.textContent = "?";
      statWaiting.textContent = "?";
      transferHint.textContent = "";
      return;
    }
    const { settings, tapMode, showToggle } = reply;
    tapToggle.checked = await effectiveTapMode(tapMode);
    showToggleInput.checked = showToggle !== false;
    updateHint();
    appUrlInput.value = settings.appUrl ?? "";
    urlInput.value = settings.url ?? "";
    tokenInput.value = settings.token ?? "";
    const stats = await sendMessage({ type: "stats" }).catch(() => void 0) ?? {
      total: 0,
      waiting: 0,
      lastHandoffAt: null,
      version: null
    };
    statTotal.textContent = String(stats.total);
    statWaiting.textContent = String(stats.waiting);
    appUrl = stats.appUrl ?? appUrlInput.value.trim();
    transferHint.textContent = describeTransfer(stats);
    openAppBtn.style.display = stats.linked === false && appUrl ? "" : "none";
    pushBtn.style.display = stats.waiting > 0 ? "" : "none";
    if (stats.version) versionLabel.textContent = `Yomeyo ${stats.version}`;
    await refreshAudioPermission();
  }
  tapToggle.addEventListener("change", () => {
    updateHint();
    void sendMessage({ type: "setTapMode", enabled: tapToggle.checked });
  });
  showToggleInput.addEventListener("change", () => {
    void sendMessage({ type: "setShowToggle", enabled: showToggleInput.checked });
  });
  async function saveSettings() {
    await sendMessage({
      type: "setSettings",
      settings: {
        appUrl: appUrlInput.value.trim(),
        url: urlInput.value.trim(),
        token: tokenInput.value
      }
    });
  }
  for (const input of [appUrlInput, urlInput, tokenInput]) {
    input.addEventListener("change", () => void saveSettings());
  }
  pushBtn.addEventListener("click", async () => {
    await saveSettings();
    pushBtn.disabled = true;
    setMessage("Sending\u2026");
    const result = await sendMessage({ type: "pushNow" }).catch(() => void 0);
    pushBtn.disabled = false;
    if (!result || result.error) {
      setMessage(result?.error ?? "Yomeyo's background did not answer.", "error");
      return;
    }
    const extra = result.synced ? ` Sync server: pushed ${result.synced.pushed}, pulled ${result.synced.pulled}.` : "";
    if (result.state === "delivered" || result.state === "nothing-to-do") {
      setMessage((result.state === "delivered" ? "Sent." : "Nothing waiting.") + extra, "ok");
    } else {
      setMessage(explain(result.state, result.appUrl ?? appUrl) + extra, "error");
    }
    void refresh();
  });
  openAppBtn.addEventListener("click", () => {
    if (!appUrl) return;
    try {
      ext.tabs?.create?.({ url: appUrl });
    } catch {
      window.open(appUrl, "_blank");
    }
  });
  void sendMessage({ type: "deliverNow" }).catch(() => void 0).then(() => refresh());
  var AUDIO_ORIGINS = { origins: ["*://*/*"] };
  function permissionsApi() {
    return globalThis.chrome?.permissions ?? globalThis.browser?.permissions;
  }
  function hasAudioPermission() {
    const api = permissionsApi();
    if (!api) return Promise.resolve(false);
    return new Promise((resolve) => {
      try {
        const result = api.contains(AUDIO_ORIGINS, resolve);
        if (result && typeof result.then === "function") result.then(resolve, () => resolve(false));
      } catch {
        resolve(false);
      }
    });
  }
  async function refreshAudioPermission() {
    const api = permissionsApi();
    if (!api) {
      audioHint.textContent = "";
      audioAllowBtn.style.display = "none";
      return;
    }
    if (await hasAudioPermission()) {
      audioHint.textContent = "Audio downloads are allowed.";
      audioAllowBtn.style.display = "none";
    } else {
      audioHint.textContent = "Pronunciation audio services usually refuse web pages. Allow this, and the app can fetch them through the extension.";
      audioAllowBtn.style.display = "";
    }
  }
  audioAllowBtn.addEventListener("click", () => {
    const api = permissionsApi();
    if (!api) return;
    try {
      const result = api.request(AUDIO_ORIGINS, () => void refreshAudioPermission());
      if (result && typeof result.then === "function") result.then(() => void refreshAudioPermission());
    } catch {
      setMessage("This browser would not show the permission prompt.", "error");
    }
  });
})();
