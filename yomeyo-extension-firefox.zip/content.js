(() => {
  // ../../packages/core/dist/dictionary.js
  function isJapaneseChar(ch) {
    const code = ch.codePointAt(0);
    if (code === void 0)
      return false;
    return code >= 12353 && code <= 12447 || // hiragana
    code >= 12448 && code <= 12543 || // katakana
    code >= 19968 && code <= 40959 || // CJK unified
    code >= 13312 && code <= 19903 || // CJK ext A
    code === 12293 || // 々
    code === 12540;
  }

  // ../../packages/core/dist/tap.js
  var TAP_SLOP_PX = 24;
  function pointOf(ev) {
    const touch = ev?.changedTouches?.[0] ?? ev?.touches?.[0];
    if (touch)
      return { x: touch.clientX, y: touch.clientY };
    if (typeof ev?.clientX === "number")
      return { x: ev.clientX, y: ev.clientY };
    return null;
  }
  function onTap(target, handler, options = {}) {
    const slop = options.slop ?? TAP_SLOP_PX;
    const graceMs = options.clickGraceMs ?? 500;
    const timer = options.setTimeout ?? ((fn, ms) => setTimeout(fn, ms));
    let from = null;
    let done = false;
    let justHandled = false;
    const begin = (ev) => {
      if (typeof ev?.button === "number" && ev.button > 0) {
        from = null;
        return;
      }
      from = pointOf(ev);
      done = false;
    };
    const end = (ev) => {
      const start = from;
      from = null;
      if (!start || done)
        return;
      const at = pointOf(ev);
      if (!at)
        return;
      const dx = at.x - start.x;
      const dy = at.y - start.y;
      if (Math.sqrt(dx * dx + dy * dy) > slop)
        return;
      done = true;
      justHandled = true;
      timer(() => {
        justHandled = false;
      }, graceMs);
      handler(ev);
    };
    target.addEventListener("pointerdown", begin);
    target.addEventListener("touchstart", begin);
    target.addEventListener("touchcancel", () => {
      from = null;
    });
    target.addEventListener("pointerup", end);
    target.addEventListener("touchend", end);
    target.addEventListener("click", (ev) => {
      if (justHandled) {
        justHandled = false;
        return;
      }
      handler(ev);
    });
  }

  // src/browser.ts
  var globalAny = globalThis;
  var ext = typeof globalAny.browser !== "undefined" && globalAny.browser?.runtime ? globalAny.browser : globalAny.chrome;
  var promiseStyle = typeof globalAny.browser !== "undefined" && globalAny.browser?.runtime !== void 0;
  function sendMessage(message) {
    if (promiseStyle) return ext.runtime.sendMessage(message);
    return new Promise((resolve) => {
      ext.runtime.sendMessage(message, (response) => {
        void ext.runtime.lastError;
        resolve(response);
      });
    });
  }
  function storageGet(keys) {
    if (promiseStyle) return ext.storage.local.get(keys);
    return new Promise((resolve) => ext.storage.local.get(keys, resolve));
  }

  // src/frame-handoff.ts
  var FROM_EXTENSION = "yomeyo-extension";
  var FROM_FRAME = "yomeyo-sync-frame";
  var TIMEOUT_MS = 2e4;
  function handOverViaFrame(frameUrl, cards, token) {
    return new Promise((resolve, reject) => {
      const frame = document.createElement("iframe");
      frame.style.cssText = "position:absolute;left:-9999px;top:0;width:1px;height:1px;border:0";
      let settled = false;
      const finish = (err, ids = []) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        window.removeEventListener("message", onMessage);
        frame.remove();
        if (err) reject(err);
        else resolve(ids);
      };
      const onMessage = (ev) => {
        const data = ev.data;
        if (data?.source !== FROM_FRAME) return;
        if (data.type === "ready") {
          frame.contentWindow?.postMessage({ source: FROM_EXTENSION, type: "cards", cards, token }, "*");
        } else if (data.type === "stored") {
          finish(null, Array.isArray(data.ids) ? data.ids : []);
        } else if (data.type === "failed") {
          finish(new Error(data.error ?? "the app could not store the words"));
        }
      };
      const timer = setTimeout(() => finish(new Error("the app's page did not answer")), TIMEOUT_MS);
      window.addEventListener("message", onMessage);
      frame.src = frameUrl;
      document.body.appendChild(frame);
    });
  }

  // src/content.ts
  var IS_TOUCH = typeof matchMedia === "function" ? matchMedia("(pointer: coarse)").matches || navigator.maxTouchPoints > 0 : navigator.maxTouchPoints > 0;
  var isAppPage = false;
  function pageIsApp(appUrl) {
    try {
      const base = new URL(appUrl);
      if (location.origin !== base.origin) return false;
      const dir = base.pathname.replace(/[^/]*$/, "");
      return location.pathname.startsWith(dir);
    } catch {
      return false;
    }
  }
  window.addEventListener("message", (ev) => {
    if (ev.source !== window) return;
    const data = ev.data;
    if (data?.source !== "yomeyo-app" || data.type !== "fetch") return;
    if (typeof data.url !== "string" || typeof data.id !== "string") return;
    window.postMessage({ source: "yomeyo-extension", type: "fetching", id: data.id }, location.origin);
    void sendMessage({
      type: "fetchForApp",
      url: data.url
    }).catch(() => ({ error: "the extension could not be reached" })).then((res) => {
      window.postMessage(
        {
          source: "yomeyo-extension",
          type: "fetched",
          id: data.id,
          base64: res?.base64 ?? "",
          contentType: res?.contentType ?? "",
          error: res?.error ?? ""
        },
        location.origin
      );
    });
  });
  var offerToApp = null;
  async function offerSavedWordsToApp(appUrl) {
    if (!pageIsApp(appUrl)) return;
    isAppPage = true;
    removeHost();
    const greet = () => {
      window.postMessage(
        {
          source: "yomeyo-extension",
          type: "hello",
          version: ext.runtime?.getManifest?.().version ?? null
        },
        location.origin
      );
    };
    const offer = async () => {
      greet();
      const cards = await sendMessage({ type: "pendingForApp" }).catch(() => null);
      if (!cards?.length) return;
      window.postMessage({ source: "yomeyo-extension", type: "cards", cards }, location.origin);
    };
    offerToApp = offer;
    window.addEventListener("message", (ev) => {
      if (ev.source !== window) return;
      const data = ev.data;
      if (data?.source !== "yomeyo-app") return;
      if (data.type === "ready") void offer();
      if (data.type === "imported") void sendMessage({ type: "handedOff", ids: data.ids });
      if (data.type === "token" && typeof data.token === "string") {
        void sendMessage({ type: "setHandoverToken", token: data.token });
      }
    });
    document.addEventListener("visibilitychange", () => {
      if (!document.hidden) void offer();
    });
    window.addEventListener("pageshow", () => void offer());
    await offer();
  }
  var tapModeSetting;
  var showToggle = true;
  function tapModeActive() {
    if (isAppPage) return false;
    return tapModeSetting ?? IS_TOUCH;
  }
  void storageGet(["tapMode", "showToggle"]).then(
    (data) => {
      if (typeof data?.tapMode === "boolean") tapModeSetting = data.tapMode;
      if (typeof data?.showToggle === "boolean") showToggle = data.showToggle;
      renderToggle();
      if (tapModeActive()) void sendMessage({ type: "warm" }).catch(() => {
      });
    }
  );
  var audioBase = "";
  void sendMessage({ type: "getSettings" }).then((data) => {
    const appUrl = data?.settings?.appUrl?.trim();
    if (appUrl) {
      audioBase = appUrl;
      return offerSavedWordsToApp(appUrl);
    }
    return void 0;
  }).catch(() => {
  });
  ext.storage?.onChanged?.addListener((changes) => {
    if ("tapMode" in changes) {
      const value = changes.tapMode.newValue;
      tapModeSetting = typeof value === "boolean" ? value : void 0;
    }
    if ("showToggle" in changes) showToggle = changes.showToggle.newValue !== false;
    renderToggle();
  });
  async function setTapMode(enabled) {
    tapModeSetting = enabled;
    renderToggle();
    if (!enabled) closePopup();
    await sendMessage({ type: "setTapMode", enabled });
  }
  var host = null;
  var shadow = null;
  var POPUP_CSS = `
  :host { all: initial; }
  * { box-sizing: border-box; }
  .sheet {
    position: fixed;
    /* One below the toggle: the on/off control must never be covered by a
       definition, or there is no way to dismiss lookups while one is open. */
    z-index: 2147483646;
    left: 0; right: 0; bottom: 0;
    margin: 0 auto;
    max-width: 560px;
    max-height: 55vh;
    display: flex;
    flex-direction: column;
    background: #1c1c2e;
    color: #eceaf4;
    border: 1px solid rgba(255,255,255,0.14);
    border-bottom: none;
    border-radius: 18px 18px 0 0;
    box-shadow: 0 -6px 40px rgba(0,0,0,0.55);
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Hiragino Sans", "Noto Sans JP", sans-serif;
    font-size: 15px;
    line-height: 1.45;
    padding-bottom: env(safe-area-inset-bottom);
    animation: rise 140ms ease-out;
  }
  @keyframes rise { from { transform: translateY(12px); opacity: 0 } to { transform: none; opacity: 1 } }
  @media (min-width: 700px) {
    .sheet { left: auto; right: 16px; bottom: 16px; border-radius: 14px; border-bottom: 1px solid rgba(255,255,255,0.14); width: 420px; }
  }
  /* Desktop: pinned beside the looked-up word rather than a corner sheet.
     left/top arrive as inline styles once the size is known. */
  .sheet.anchored {
    left: auto; right: auto; bottom: auto;
    width: 400px;
    max-height: 340px;
    border-radius: 14px;
    border-bottom: 1px solid rgba(255,255,255,0.14);
    animation: pop 120ms ease-out;
  }
  @keyframes pop { from { transform: scale(0.96); opacity: 0 } to { transform: none; opacity: 1 } }
  .grip {
    flex: none;
    display: flex; align-items: center; gap: 10px;
    padding: 10px 14px 6px;
  }
  .grip .bar { width: 36px; height: 4px; border-radius: 2px; background: rgba(255,255,255,0.25); margin: 0 auto; }
  .grip .close {
    all: unset;
    width: 34px; height: 34px;
    display: grid; place-items: center;
    border-radius: 50%;
    color: #9a97b0; font-size: 20px; cursor: pointer;
    flex: none;
  }
  .grip .spacer { width: 34px; flex: none; }
  .list { overflow-y: auto; -webkit-overflow-scrolling: touch; padding-bottom: 6px; }
  /* Desktop popups have no grip bar; the list starts at the top edge. */
  .sheet.nogrip .list { padding-top: 2px; }
  .sheet.nogrip .entry:first-child { border-top: none; }
  .entry {
    display: flex; gap: 12px; align-items: center;
    padding: 12px 14px;
    border-top: 1px solid rgba(255,255,255,0.06);
  }
  .word { flex: 1; min-width: 0; }
  .term { font-size: 20px; font-weight: 700; }
  .reading { color: #a99df5; margin-left: 8px; font-size: 14px; }
  .reasons { color: #9a97b0; font-size: 12px; margin-top: 2px; }
  .glosses { margin-top: 4px; color: #eceaf4; overflow-wrap: anywhere; }
  .pos { color: #9a97b0; font-size: 11px; margin-top: 3px; }
  button.save {
    all: unset;
    background: #7c6cf0; color: #fff;
    min-width: 76px; min-height: 44px;
    padding: 0 16px;
    border-radius: 12px;
    text-align: center;
    font-size: 15px; font-weight: 600;
    cursor: pointer; flex: none;
    font-family: inherit;
    touch-action: manipulation;
  }
  button.save.saved { background: #4cc38a; }
  button.save[disabled] { opacity: 0.6; }
  button.speak {
    all: unset;
    width: 40px; height: 40px;
    display: grid; place-items: center;
    border-radius: 50%;
    background: #262640;
    font-size: 16px;
    cursor: pointer; flex: none;
    touch-action: manipulation;
  }
  button.speak:active { background: #34345a; }
  button.speak[disabled] { opacity: 0.5; }
  .empty { padding: 14px; color: #9a97b0; }

  /* The always-available on/off pill. Deliberately small and translucent:
     it must never be the thing you accidentally tap while reading. */
  .toggle {
    position: fixed;
    z-index: 2147483647;
    right: 10px;
    bottom: calc(16px + env(safe-area-inset-bottom));
    transition: bottom 140ms ease, opacity 120ms ease, background 120ms ease;
    display: flex;
    align-items: center;
    gap: 6px;
    padding: 7px 11px;
    border-radius: 999px;
    background: rgba(28, 28, 46, 0.72);
    border: 1px solid rgba(255,255,255,0.16);
    color: #eceaf4;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 12px;
    font-weight: 600;
    line-height: 1;
    cursor: pointer;
    user-select: none;
    opacity: 0.5;
    transition: opacity 120ms ease, background 120ms ease;
    backdrop-filter: blur(6px);
    touch-action: manipulation;
  }
  .toggle:hover, .toggle:active { opacity: 1; }
  .toggle .dot {
    width: 9px; height: 9px; border-radius: 50%;
    background: #6b6880;
  }
  .toggle.on { opacity: 0.72; }
  .toggle.on .dot { background: #7c6cf0; box-shadow: 0 0 6px #7c6cf0; }
  .toggle .label { letter-spacing: 0.02em; min-width: 46px; }
`;
  function closePopup() {
    shadow?.querySelector(".sheet")?.remove();
    liftToggleAbove(0);
  }
  var toggleLift = 0;
  function liftToggleAbove(sheetHeight) {
    toggleLift = sheetHeight > 0 ? Math.round(sheetHeight) + 12 : 0;
    positionToggle();
  }
  function positionToggle() {
    if (!toggleEl) return;
    const gap = 10;
    const bottom = 16 + toggleLift;
    const vv = window.visualViewport;
    if (!vv) {
      toggleEl.style.left = "auto";
      toggleEl.style.top = "auto";
      toggleEl.style.right = `${gap}px`;
      toggleEl.style.bottom = `calc(${bottom}px + env(safe-area-inset-bottom))`;
      return;
    }
    const rect = toggleEl.getBoundingClientRect();
    const width = rect.width || 108;
    const height = rect.height || 29;
    toggleEl.style.right = "auto";
    toggleEl.style.bottom = "auto";
    toggleEl.style.left = `${Math.round(vv.offsetLeft + vv.width - width - gap)}px`;
    toggleEl.style.top = `${Math.round(vv.offsetTop + vv.height - height - bottom)}px`;
  }
  if (window.visualViewport) {
    window.visualViewport.addEventListener("resize", positionToggle);
    window.visualViewport.addEventListener("scroll", positionToggle);
  } else {
    window.addEventListener("resize", positionToggle);
  }
  function ensureHost() {
    if (shadow) return shadow;
    host = document.createElement("div");
    host.id = "yomeyo-popup-host";
    host.style.cssText = "all: initial; position: fixed; top: 0; left: 0; width: 0; height: 0; z-index: 2147483647;";
    shadow = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = POPUP_CSS;
    shadow.appendChild(style);
    document.documentElement.appendChild(host);
    return shadow;
  }
  function removeHost() {
    host?.remove();
    host = null;
    shadow = null;
    toggleEl = null;
  }
  var toggleEl = null;
  function renderToggle() {
    if (isAppPage) {
      removeHost();
      return;
    }
    if (!showToggle) {
      toggleEl?.remove();
      toggleEl = null;
      return;
    }
    const root = ensureHost();
    if (!toggleEl) {
      toggleEl = document.createElement("div");
      toggleEl.className = "toggle";
      toggleEl.setAttribute("role", "switch");
      const dot = document.createElement("span");
      dot.className = "dot";
      const label = document.createElement("span");
      label.className = "label";
      toggleEl.append(dot, label);
      onTap(toggleEl, (ev) => {
        ev.stopPropagation?.();
        ev.preventDefault?.();
        void setTapMode(!tapModeActive());
      });
      for (const type of ["pointerdown", "pointerup", "touchstart", "mousedown", "click"]) {
        toggleEl.addEventListener(type, (ev) => ev.stopPropagation());
      }
      root.appendChild(toggleEl);
    }
    positionToggle();
    const on = tapModeActive();
    toggleEl.classList.toggle("on", on);
    toggleEl.setAttribute("aria-checked", String(on));
    toggleEl.querySelector(".label").textContent = on ? "Tap: on" : "Tap: off";
    toggleEl.title = on ? "Tap to turn lookups off" : "Tap to turn lookups on";
  }
  function showMessageSheet(text) {
    closePopup();
    const root = ensureHost();
    const sheet = document.createElement("div");
    sheet.className = "sheet";
    const note = document.createElement("div");
    note.className = "empty";
    note.textContent = text;
    sheet.appendChild(note);
    root.appendChild(sheet);
    for (const type of ["click", "pointerdown", "pointerup", "touchstart"]) {
      sheet.addEventListener(type, (ev) => ev.stopPropagation());
    }
    const dismiss = (ev) => {
      if (host && ev.composedPath().includes(host)) return;
      closePopup();
      document.removeEventListener("pointerdown", dismiss, true);
    };
    setTimeout(() => document.addEventListener("pointerdown", dismiss, true), 0);
  }
  function placeAnchored(sheet, anchor) {
    const margin = 8;
    const rect = sheet.getBoundingClientRect();
    if (anchor.vertical) {
      let left2 = anchor.left - rect.width - margin;
      if (left2 < margin) {
        left2 = Math.min(anchor.right + margin, Math.max(margin, window.innerWidth - rect.width - margin));
      }
      const top2 = Math.round(
        Math.min(Math.max(margin, anchor.top), Math.max(margin, window.innerHeight - rect.height - margin))
      );
      sheet.style.left = `${Math.round(Math.max(margin, left2))}px`;
      sheet.style.top = `${top2}px`;
      return;
    }
    const left = Math.round(
      Math.min(Math.max(margin, anchor.left), Math.max(margin, window.innerWidth - rect.width - margin))
    );
    let top = anchor.bottom + margin;
    if (top + rect.height > window.innerHeight - margin) {
      top = anchor.top - rect.height - margin;
      if (top < margin) top = Math.max(margin, window.innerHeight - rect.height - margin);
    }
    sheet.style.left = `${left}px`;
    sheet.style.top = `${Math.round(top)}px`;
  }
  async function showPopup(matches, sentence, anchor) {
    closePopup();
    const root = ensureHost();
    const sheet = document.createElement("div");
    sheet.className = "sheet";
    const anchored = anchor !== void 0 && !IS_TOUCH;
    if (anchored) sheet.classList.add("anchored");
    if (!IS_TOUCH) sheet.classList.add("nogrip");
    if (IS_TOUCH) {
      const grip = document.createElement("div");
      grip.className = "grip";
      const spacer = document.createElement("div");
      spacer.className = "spacer";
      const bar = document.createElement("div");
      bar.className = "bar";
      const close = document.createElement("button");
      close.className = "close";
      close.textContent = "\u2715";
      close.setAttribute("aria-label", "Close");
      onTap(close, closePopup);
      grip.append(spacer, bar, close);
      sheet.appendChild(grip);
    }
    const list = document.createElement("div");
    list.className = "list";
    sheet.appendChild(list);
    root.appendChild(sheet);
    for (const type of ["click", "pointerdown", "pointerup", "touchstart"]) {
      sheet.addEventListener(type, (ev) => ev.stopPropagation());
    }
    let shown = 0;
    for (const match of matches.slice(0, 6)) {
      for (const entry of match.entries.slice(0, 2)) {
        list.appendChild(await buildEntryRow(match, entry, sentence));
        shown++;
      }
    }
    if (shown === 0) {
      const empty = document.createElement("div");
      empty.className = "empty";
      empty.textContent = "No dictionary entry found.";
      list.appendChild(empty);
    }
    if (anchored && anchor) {
      placeAnchored(sheet, anchor);
      liftToggleAbove(0);
    } else {
      liftToggleAbove(sheet.getBoundingClientRect().height);
    }
    const dismiss = (ev) => {
      if (host && ev.composedPath().includes(host)) return;
      closePopup();
      document.removeEventListener("pointerdown", dismiss, true);
    };
    setTimeout(() => document.addEventListener("pointerdown", dismiss, true), 0);
  }
  var speakingClip = null;
  async function playEntryAudio(entry, button) {
    button.disabled = true;
    const done = () => {
      button.disabled = false;
    };
    speakingClip?.pause();
    speakingClip = null;
    const fallback = () => {
      try {
        speechSynthesis.cancel();
        const utterance = new SpeechSynthesisUtterance(entry.reading || entry.term);
        utterance.lang = "ja-JP";
        utterance.onend = done;
        utterance.onerror = done;
        speechSynthesis.speak(utterance);
      } catch {
        done();
      }
    };
    if (!audioBase) return fallback();
    try {
      const base = audioBase.endsWith("/") ? audioBase : audioBase + "/";
      const url = new URL(
        `audio.php?term=${encodeURIComponent(entry.term)}&reading=${encodeURIComponent(entry.reading || entry.term)}`,
        base
      ).href;
      const clip = new Audio(url);
      speakingClip = clip;
      clip.addEventListener("ended", done);
      clip.addEventListener("error", () => {
        if (speakingClip === clip) speakingClip = null;
        fallback();
      });
      await clip.play();
    } catch {
      fallback();
    }
  }
  async function buildEntryRow(match, entry, sentence) {
    const row = document.createElement("div");
    row.className = "entry";
    const word = document.createElement("div");
    word.className = "word";
    const title = document.createElement("div");
    const term = document.createElement("span");
    term.className = "term";
    term.textContent = entry.term;
    title.appendChild(term);
    if (entry.reading && entry.reading !== entry.term) {
      const reading = document.createElement("span");
      reading.className = "reading";
      reading.textContent = entry.reading;
      title.appendChild(reading);
    }
    word.appendChild(title);
    if (match.reasons.length > 0) {
      const reasons = document.createElement("div");
      reasons.className = "reasons";
      reasons.textContent = `${match.matchedText} \u2190 ${match.reasons.join(" \u2190 ")}`;
      word.appendChild(reasons);
    }
    const glosses = document.createElement("div");
    glosses.className = "glosses";
    glosses.textContent = entry.glosses.join(" \xB7 ");
    word.appendChild(glosses);
    if (entry.pos.length > 0) {
      const pos = document.createElement("div");
      pos.className = "pos";
      pos.textContent = entry.pos.join(", ");
      word.appendChild(pos);
    }
    row.appendChild(word);
    const say = document.createElement("button");
    say.className = "speak";
    say.textContent = "\u{1F50A}";
    say.setAttribute("aria-label", "Play pronunciation");
    onTap(say, () => void playEntryAudio(entry, say));
    row.appendChild(say);
    const btn = document.createElement("button");
    btn.className = "save";
    const saved = await sendMessage({
      type: "isSaved",
      term: entry.term,
      reading: entry.reading
    });
    if (saved) {
      btn.textContent = "Saved";
      btn.classList.add("saved");
      btn.disabled = true;
    } else {
      btn.textContent = "+ Save";
      onTap(btn, async () => {
        if (btn.disabled) return;
        btn.disabled = true;
        const res = await sendMessage({
          type: "save",
          entry,
          sentence,
          url: location.href
        });
        btn.textContent = res?.outcome === "duplicate" ? "Already saved" : "Saved";
        btn.classList.add("saved");
      });
    }
    row.appendChild(btn);
    return row;
  }
  function textAtPoint(x, y) {
    let node = null;
    let offset = 0;
    const doc = document;
    if (doc.caretPositionFromPoint) {
      const pos = doc.caretPositionFromPoint(x, y);
      if (pos) {
        node = pos.offsetNode;
        offset = pos.offset;
      }
    } else if (doc.caretRangeFromPoint) {
      const range = doc.caretRangeFromPoint(x, y);
      if (range) {
        node = range.startContainer;
        offset = range.startOffset;
      }
    }
    if (!node || node.nodeType !== Node.TEXT_NODE) return null;
    const textNode = node;
    const content = textNode.data;
    if (content.length === 0) return null;
    if (offset >= content.length) offset = content.length - 1;
    if (offset < 0) return null;
    const onGlyph = (at) => {
      try {
        const glyph = document.createRange();
        glyph.setStart(textNode, at);
        glyph.setEnd(textNode, at + 1);
        const box = glyph.getBoundingClientRect();
        const slack = 4;
        return x >= box.left - slack && x <= box.right + slack && y >= box.top - slack && y <= box.bottom + slack;
      } catch {
        return false;
      }
    };
    for (const at of [offset, offset - 1, offset + 1]) {
      if (at < 0 || at >= content.length) continue;
      if (!isJapaneseChar(content[at])) continue;
      if (onGlyph(at)) return flattenAround(textNode, at);
    }
    return null;
  }
  function flattenAround(tapped, tapOffset) {
    let container = tapped.parentElement ?? document.body;
    for (let hops = 0; hops < 8 && container.parentElement; hops++) {
      let display = "";
      try {
        display = getComputedStyle(container).display;
      } catch {
        break;
      }
      if (!display.startsWith("inline") && display !== "contents" && display !== "ruby") break;
      container = container.parentElement;
    }
    const pieces = [];
    let tappedAt = -1;
    const walker = document.createTreeWalker(container, NodeFilter.SHOW_TEXT);
    for (let node = walker.nextNode(); node; node = walker.nextNode()) {
      const text2 = node;
      if (text2.parentElement?.closest("rt,rp,script,style,noscript")) continue;
      if (text2 === tapped) tappedAt = pieces.length;
      pieces.push(text2);
    }
    if (tappedAt < 0) {
      return { text: tapped.data, offset: tapOffset, node: tapped, locate: (at) => ({ node: tapped, offset: at }) };
    }
    let first = tappedAt;
    let behind = tapOffset;
    while (first > 0 && behind < 40) behind += pieces[--first].data.length;
    let last = tappedAt;
    let ahead = pieces[tappedAt].data.length - tapOffset;
    while (last < pieces.length - 1 && ahead < 60) ahead += pieces[++last].data.length;
    const kept = pieces.slice(first, last + 1);
    const starts = [];
    let text = "";
    for (const piece of kept) {
      starts.push(text.length);
      text += piece.data;
    }
    const offset = starts[tappedAt - first] + tapOffset;
    return {
      text,
      offset,
      node: tapped,
      locate(at) {
        for (let i = kept.length - 1; i >= 0; i--) {
          if (at >= starts[i]) {
            return { node: kept[i], offset: Math.min(at - starts[i], kept[i].data.length) };
          }
        }
        return { node: kept[0], offset: 0 };
      }
    };
  }
  function isVerticalText(node) {
    const el = node.nodeType === Node.TEXT_NODE ? node.parentElement : node;
    if (!el || !(el instanceof Element)) return false;
    try {
      const mode = getComputedStyle(el).writingMode ?? "";
      return mode.startsWith("vertical") || mode.startsWith("sideways");
    } catch {
      return false;
    }
  }
  function sentenceAround(text, offset) {
    const isBreak = (ch) => "\u3002\uFF01\uFF1F!?\n".includes(ch);
    let start = offset;
    while (start > 0 && !isBreak(text[start - 1])) start--;
    let end = offset;
    while (end < text.length && !isBreak(text[end])) end++;
    if (end < text.length) end++;
    return text.slice(start, end).trim();
  }
  async function handleLookupAt(x, y) {
    const tap = textAtPoint(x, y);
    if (!tap) return false;
    const matches = await sendMessage({
      type: "lookup",
      text: tap.text,
      offset: tap.offset
    }).catch(() => void 0);
    if (!matches) {
      showMessageSheet(
        "Could not reach Yomeyo's dictionary. Reload the page; if that does not help, remove the extension and install it again."
      );
      return true;
    }
    if (matches.length === 0) return false;
    const vertical = isVerticalText(tap.node);
    let anchor = { left: x, top: y, right: x, bottom: y, vertical };
    try {
      const range = document.createRange();
      const from = tap.locate(Math.max(0, matches[0].start));
      const to = tap.locate(Math.min(tap.text.length, matches[0].start + matches[0].matchLength));
      range.setStart(from.node, from.offset);
      range.setEnd(to.node, to.offset);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
      const rect = range.getBoundingClientRect();
      if (rect.width > 0 || rect.height > 0) {
        anchor = { left: rect.left, top: rect.top, right: rect.right, bottom: rect.bottom, vertical };
      }
    } catch {
    }
    await showPopup(matches, sentenceAround(tap.text, tap.offset), anchor);
    return true;
  }
  var lastTouchStart = { x: 0, y: 0, t: 0 };
  var moved = false;
  document.addEventListener(
    "touchstart",
    (ev) => {
      const touch = ev.touches[0];
      if (!touch) return;
      lastTouchStart = { x: touch.clientX, y: touch.clientY, t: Date.now() };
      moved = false;
    },
    { capture: true, passive: true }
  );
  document.addEventListener(
    "touchmove",
    (ev) => {
      const touch = ev.touches[0];
      if (!touch) return;
      if (Math.hypot(touch.clientX - lastTouchStart.x, touch.clientY - lastTouchStart.y) > 10) {
        moved = true;
      }
    },
    { capture: true, passive: true }
  );
  document.addEventListener(
    "click",
    (ev) => {
      if (host && ev.composedPath().includes(host)) return;
      const wantsLookup = ev.altKey || tapModeActive();
      if (!wantsLookup) {
        closePopup();
        return;
      }
      if (moved || lastTouchStart.t && Date.now() - lastTouchStart.t > 700) {
        moved = false;
        return;
      }
      const x = ev.clientX;
      const y = ev.clientY;
      const tap = textAtPoint(x, y);
      if (!tap) {
        closePopup();
        return;
      }
      void handleLookupAt(x, y).then((found) => {
        if (!found) closePopup();
      });
      const target = ev.target;
      const interactive = target?.closest?.("a,button,input,textarea,select,[contenteditable]");
      if (interactive) {
        ev.preventDefault();
        ev.stopPropagation();
      }
    },
    true
  );
  ext.runtime.onMessage?.addListener((message, _sender, sendResponse) => {
    if (message?.type === "getTapState") {
      sendResponse({ active: tapModeActive(), isTouch: IS_TOUCH, explicit: tapModeSetting });
      return true;
    }
    if (message?.type === "deliverViaFrame") {
      handOverViaFrame(message.frameUrl, message.cards, message.token).then(
        (ids) => sendResponse({ ids }),
        (err) => sendResponse({ error: err instanceof Error ? err.message : String(err) })
      );
      return true;
    }
    if (message?.type === "appHasNewWords") {
      void offerToApp?.();
      sendResponse({ ok: true });
      return true;
    }
    if (message?.type === "lookupSelection") {
      const selection = window.getSelection();
      const text = selection?.toString() ?? "";
      if (text.trim()) {
        let anchor;
        try {
          const range = selection.getRangeAt(0);
          const rect = range.getBoundingClientRect();
          if (rect.width > 0 || rect.height > 0) {
            anchor = {
              left: rect.left,
              top: rect.top,
              right: rect.right,
              bottom: rect.bottom,
              vertical: isVerticalText(range.startContainer)
            };
          }
        } catch {
        }
        void sendMessage({ type: "lookup", text, offset: 0 }).then((matches) => {
          if (matches?.length) void showPopup(matches, text, anchor);
        });
      }
      sendResponse({ ok: true });
      return true;
    }
    return void 0;
  });
})();
